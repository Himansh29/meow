echo "enter name"
read name
echo "you entered $name"
echo "address"
read addr
echo "Address : $addr"
kdf sfj lkjfvlkjdf
