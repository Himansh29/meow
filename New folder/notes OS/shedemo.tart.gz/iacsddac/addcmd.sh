a=$1
b=$2
c=`expr $a + $b`

let s=a+b

echo "addition : $c"
echo "Addition : $s"
