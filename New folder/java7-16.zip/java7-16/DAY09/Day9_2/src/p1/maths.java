package p1;

public interface maths 
{
	public void add();
	public void sub();
	public void mul();
	public void div();
	
}

