package p1;

@Author(firstName="Akshita",lastName="Chanchlani")
public class Book 
{
	//@Author(firstName="Akshita",lastName="Chanchlani") //disallowed for the location 
	int num=50;
	
}
