import java.util.ArrayList;

public class Day13_1 {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		ArrayList<Integer> a1=new ArrayList<Integer>();
		a1.add(10);
		a1.add(20);
		
		//boolean b = a1.contains(20);
		//System.out.println(b);
		
		System.out.println(a1.contains(20));
		
	}

}
