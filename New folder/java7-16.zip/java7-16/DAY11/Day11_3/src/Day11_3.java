
// Unchecked , if we use throw then its not compulsory to handle it using try/catch or using throws

// Checked : it is compulsory to handle it , either by try/catch or by using throws

/*

public class Day11_3 {

	public static void main(String[] args) throws InterruptedException 
	{
		System.out.println("Hello");
		Thread.sleep(1000);
		System.out.println("CJ08 Batch");

	}

}


/*
public class Day11_3 {

	public static void main(String[] args) 
	{
		String str="123";
		int i=Integer.parseInt(str);
		System.out.println(i);

	}

}

*/

