import java.util.Arrays;


// difference between 
//nameofanarray.toString()
// Arrays.toString(nameofanarray)


public class Day6_1 {

	public static void main(String[] args) 
	{
		boolean arr1[]=new boolean[3];
		System.out.println(Arrays.toString(arr1));
		
		byte arr2[]=new byte[3];
		System.out.println(Arrays.toString(arr2));
		
		int arr3[]=new int[3];
		System.out.println(Arrays.toString(arr3));
		
		float arr4[]=new float[3];
		System.out.println(Arrays.toString(arr4));
		
		double arr5[]=new double[3];
		System.out.println(Arrays.toString(arr5));

	}

}






/*
public class Day6_1 {

	public static void main(String[] args) 
	{
		boolean arr1[]=new boolean[3];
		System.out.println(arr1.toString());
		
		byte arr2[]=new byte[3];
		System.out.println(arr2.toString());
		
		int arr3[]=new int[3];
		System.out.println(arr3.toString());
		
		float arr4[]=new float[3];
		System.out.println(arr4.toString());
		
		double arr5[]=new double[3];
		System.out.println(arr5.toString());

	}

}

*/
