
public class Day5_1 {

	public static void main(String[] args)
	{
		int num;
		num=Integer.parseInt(args[0]);
		// ArrayIndexOutOfBoundsException
		// it occurs when user does not suppy any value to an array
		// if the expectation of program is to get element in an array
		
		// this exception may occur if the user is trying to access
		//wrong index element from an array
		
		System.out.println("Num = "+num);

	}

}
