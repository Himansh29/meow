// Number of .class files created
//are equal to number of classes present in the source file 

// Creating a java file
//compilation of java file
//execution of java file
// putting .class files in bin folder (javac -d .\bin prg.java)

class Test
{
    public static void main(String args[])
    {
        System.out.println("Welome you all.. CJ_O_08");
        System.out.println("Hello All");
    }
}


//javac -d .\bin Test.java
