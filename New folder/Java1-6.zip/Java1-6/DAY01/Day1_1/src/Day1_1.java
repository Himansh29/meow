// how to change the perspective
//how to create java project
//how to create a class
// how to execute a program 


class Day1_1 {

	public static void main(String[] args) 
	{
		System.out.println("Welcome you all... CJ_O_08 batch");
	}

}

//main() it is a keyword (entry point method)


// we should declare main() as static
// because we donot create object of the class in which main() is residing (present)

//who calls main??? JVM (OS) 
// OS outside the application
// it should be declared as public 

//void is written because main() is not returning any value

//String args[] is used to accept Command line Arguments 





