

public class Day2_5
{
	
}



/*
public class Day2_5 {

	public static void main(String args[]) 
	{
		System.out.println("Day2_5");

	}

}

*/



/*
public class Day2_5 {

	public static void main(String[] args) 
	{
		System.out.println("Day2_5");

	}

}
*/



/*
public class Day2_5 {

	public static void main(String... args) 
	{
		System.out.println("Day2_5");

	}

}
*/