class A
{
    public static void main(String args[])
    {
        System.out.println("Day2 : VS CODE");
    }
}

class B
{

}

class Demo
{
    
}

// java Demo // compiler will try to search main() inside Demo class
// java B
// compiler will search for main() inside the class B
