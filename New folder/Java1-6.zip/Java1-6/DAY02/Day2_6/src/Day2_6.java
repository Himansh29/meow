

class Day2_6
{
	int a=45; // field variable 
	public static void main(String[] args) 
	{
		int b=55;// local variable / method local variable 
		System.out.println("B = "+b);
		
		
	}
}





/*
public class Day2_6 {

	public static void main(String[] args) 
	{
		int num=35;
		float fval=2.5f;
		double d=5.5;
		System.out.println("Num "+num);
		System.out.println("FVAL "+fval);
		System.out.println("D  "+d);
		
		
	}
}
*/





/*

//Rule : java is called as STATICALLY TYPED LANGUAGE
// it means we need to specify the data type of variables compulsory

public class Day2_6 {

	public static void main(String[] args) 
	{
		i=50; // datatype is not mentioned 
		
		System.out.println(i);
	}
}

*/




/*
public class Day2_6 {

	public static void main(String[] args) 
	{
		int i=50;
		System.out.println(i);
	}
}
*/




/*

// rule: we need to initialize the variable before its use
public class Day2_6 {

	public static void main(String[] args) 
	{
		int i;// uninitiliazed variable // javac error
		System.out.println(i);
	}
}
*/

/*
public class Day2_6 {

	public static void main(String[] args) 
	{
		int num1=20,num2=15,num3=40;
		System.out.println("Number 1 = "+num1);
		System.out.println("Number 2 = "+num2);
		System.out.println("Number 3 = "+num3);
		
		System.out.println("Number 1 = "+num1+" Number 2 = "+num2);
		
		System.out.println(num1+"  "+num2+ "  "+num3);
		System.out.println(num1+"\t"+num2+"\t"+num3);
	}
}

*/


/*
public class Day2_6 {

	public static void main(String[] args) 
	{
		int a=10,b=20,c=30;
		System.out.println(a); //10
		System.out.println(b); //20 
		System.out.println(c); //30 
		System.out.println(); // new line 
		System.out.print(a); //10
		System.out.print(b); //20 
		System.out.print(c); //30 
		System.out.println();//new line
		System.out.println(a+b+c); // 10+20+30
		
		
		
			
	}
}


*/






/*

public class Day2_6 {

	public static void main(String[] args) 
	{
		int num=50,val=60;
		System.out.println(num);
		System.out.println(val);

	}

}

*/





/*

// defining one variable and displaying 
public class Day2_6 {

	public static void main(String[] args) 
	{
		int num=50;
		System.out.println(num);

	}

}


*/