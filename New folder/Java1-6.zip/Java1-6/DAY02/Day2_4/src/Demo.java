

// The name of the file must be same as
//the name of class in which main() is residing
// so that compiler will be able to search entry point method 


class One
{
	public static void main(String[] args) {
		System.out.println("Inside Main");

	}
}
class Demo {

	

}


class Test
{
	
}
