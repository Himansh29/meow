


/*
class One
{
	
}


public class Day2_2 
{

	public static void main(String[] args)  
	{
		
		System.out.println("Hello World");
	}

}

*/



/*
public class Day2_2 {

	public  void main(String[] args)  // Compile Time Error // javac error
	{
		

	}

}

*/
